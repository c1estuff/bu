// User Authentication State
let currentUser = null;

// Add this right after the currentUser declaration at the top
const adminAccount = {
    id: "admin1",
    username: "c1e",
    password: "goblin",
    email: "admin@biggoblins.com",
    rsn: "c1e",
    role: "administrator",
    joinDate: new Date().toISOString(),
    profilePic: null
};

// New account functionality
function showLoginRegister() {
    showSection('account');
    
    // Clear any existing form data
    document.querySelectorAll('.auth-form').forEach(form => form.reset());
}

// Handle login form submission
document.getElementById('loginFormElement').addEventListener('submit', (e) => {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    
    handleLogin(username, password);
});

// Handle registration form submission
document.getElementById('registrationForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    console.log('Registration form submitted');  // Debug log
    
    const formData = {
        username: document.getElementById('regUsername').value,
        email: document.getElementById('regEmail').value,
        rsn: document.getElementById('regRsn').value,
        password: document.getElementById('regPassword').value,
        confirmPassword: document.getElementById('regConfirmPassword').value
    };
    
    // Validate form data
    if (!formData.username || !formData.email || !formData.rsn || !formData.password) {
        showMessage('All fields are required', true);
        return;
    }

    if (formData.password.length < 6) {
        showMessage('Password must be at least 6 characters', true);
        return;
    }

    if (formData.password !== formData.confirmPassword) {
        showMessage('Passwords do not match!', true);
        return;
    }
    
    try {
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        
        if (users.some(user => user.username === formData.username)) {
            showMessage('Username already taken!', true);
            return;
        }
        
        const newUser = {
            id: Date.now().toString(),
            username: formData.username,
            email: formData.email,
            rsn: formData.rsn,
            password: formData.password,
            role: 'member',
            joinDate: new Date().toISOString(),
            profilePic: null
        };
        
        users.push(newUser);
        localStorage.setItem('users', JSON.stringify(users));
        
        // Auto-login after registration
        currentUser = newUser;
        localStorage.setItem('currentUser', JSON.stringify(newUser));
        
        showMessage('Registration successful! You are now logged in.');
        updateLoginButton(true);
        showSection('social');
        
    } catch (error) {
        console.error('Registration error:', error);
        showMessage('Registration failed. Please try again.', true);
    }
});

// Login handler
async function handleLogin(username, password) {
    try {
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        // Add admin account if it doesn't exist
        if (!users.some(user => user.username === 'c1e')) {
            users.push(adminAccount);
            localStorage.setItem('users', JSON.stringify(users));
        }

        const user = users.find(u => u.username === username && u.password === password);
        
        if (user) {
            currentUser = user;
            localStorage.setItem('currentUser', JSON.stringify(user));
            updateLoginButton(true);
            showSection('social');
            showMessage('Login successful!');
        } else {
            showMessage('Invalid username or password', true);
        }
    } catch (error) {
        console.error('Login error:', error);
        showMessage('Login failed. Please try again.', true);
    }
}

// Update login button appearance
function updateLoginButton(isLoggedIn) {
    const button = document.querySelector('.account-button');
    const icon = button.querySelector('img');
    const text = button.querySelector('span');
    
    if (isLoggedIn) {
        icon.src = 'images/Member_icon.png';
        text.textContent = currentUser.username;
        button.onclick = handleLogout;
    } else {
        icon.src = 'images/Makeover_Mage_icon.png';
        text.textContent = 'Login/Register';
        button.onclick = showLoginRegister;
    }
}

// Logout handler
function handleLogout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    updateLoginButton(false);
    showSection('home');
}

// Check for existing session
function checkSession() {
    // First check if admin account exists
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    // Always ensure admin account exists and is up to date
    if (!users.some(user => user.username === 'c1e')) {
        users.push(adminAccount);
        localStorage.setItem('users', JSON.stringify(users));
    } else {
        // Update existing admin account if needed
        const index = users.findIndex(user => user.username === 'c1e');
        users[index] = adminAccount;
        localStorage.setItem('users', JSON.stringify(users));
    }

    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        updateLoginButton(true);
    }
}

// Initialize
checkSession();

// Social Feed Functions
function createPost(content, type = 'discussion') {
    if (!currentUser) return;

    const post = {
        id: Date.now().toString(),
        userId: currentUser.id,
        username: currentUser.username,
        content,
        type,
        timestamp: new Date().toISOString(),
        likes: [],
        comments: []
    };

    // Save post
    const posts = JSON.parse(localStorage.getItem('posts') || '[]');
    posts.unshift(post);
    localStorage.setItem('posts', JSON.stringify(posts));

    // Update feed
    renderPosts();
}

function renderPosts() {
    const feedContainer = document.getElementById('socialFeed');
    const posts = JSON.parse(localStorage.getItem('posts') || '[]');
    
    feedContainer.innerHTML = posts.map(post => `
        <div class="post-card" data-type="${post.type}">
            <div class="post-header">
                <img src="assets/images/icons/clan/Member_icon.png" alt="Profile" class="post-avatar">
                <div class="post-info">
                    <h4>${post.username}</h4>
                    <span class="post-time">${new Date(post.timestamp).toLocaleString()}</span>
                </div>
            </div>
            <div class="post-content">
                ${post.content}
            </div>
            <div class="post-actions">
                <button onclick="likePost('${post.id}')" class="like-btn">
                    <i class="fas fa-heart"></i> ${post.likes.length}
                </button>
                <button onclick="showComments('${post.id}')" class="comment-btn">
                    <i class="fas fa-comment"></i> ${post.comments.length}
                </button>
            </div>
        </div>
    `).join('');
}

// Initialize social features
document.getElementById('newPostForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const content = e.target.querySelector('.post-input').value;
    if (content.trim()) {
        createPost(content);
        e.target.reset();
    }
});

// Filter posts
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        const filter = e.target.dataset.filter;
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        
        const posts = document.querySelectorAll('.post-card');
        posts.forEach(post => {
            if (filter === 'all' || post.dataset.type === filter) {
                post.style.display = 'block';
            } else {
                post.style.display = 'none';
            }
        });
    });
});

// Add success/error message display
function showMessage(message, isError = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `auth-message ${isError ? 'error' : 'success'}`;
    messageDiv.textContent = message;
    
    const form = document.querySelector('.auth-form');
    form.insertBefore(messageDiv, form.firstChild);
    
    setTimeout(() => messageDiv.remove(), 3000);
} 