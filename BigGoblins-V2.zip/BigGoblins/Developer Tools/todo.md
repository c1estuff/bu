# Development Tasks

## In Progress
- [ ] Home page content layout
- [ ] Events calendar implementation
- [ ] Member list integration

## Completed
- [x] Basic site structure
- [x] Discord widget integration
- [x] Navigation system
- [x] Dark theme styling

## Planned
- [ ] Rules page content
- [ ] Guides section
- [ ] Mobile responsiveness improvements 